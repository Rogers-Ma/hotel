<template>
  <el-row :gutter="20">
    <el-col :span="3"><el-input v-model="name" placeholder="请输入客户姓名"></el-input></el-col>
  </el-row>
</template>

<script>
export default {

}
</script>

<style>
</style>