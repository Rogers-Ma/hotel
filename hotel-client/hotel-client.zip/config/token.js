const token ={
    type: "login",
    user:{}
}


export default token;